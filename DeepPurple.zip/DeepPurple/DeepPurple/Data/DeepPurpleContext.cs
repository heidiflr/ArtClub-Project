﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using DeepPurple.Models;

namespace DeepPurple.Data
{
    public class DeepPurpleContext : DbContext
    {
        public DeepPurpleContext(DbContextOptions<DeepPurpleContext> options) : base(options)
        {

        }

        public DbSet<ResourceEvent> ResourceEvent { get; set; }
        public DbSet<Resource> Resource { get; set; }
        public DbSet<AdminEvent> AdminEventd { get; set; }
        public DbSet<Admin> Admin { get; set; }
    }
}